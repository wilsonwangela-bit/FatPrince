#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
MOD 销售候选人评估 · 结论生成器（确定性）
输入：JSON（维度分 + 否决标记 + 风险/条件），通过 stdin 或 --json 传入
输出：标准化录用结论（直接录用 / 不录用 / 有条件录用）+ 理由 + 风险 + 条件

JSON schema:
{
  "candidate": "姓名",
  "scores": {"Q1": 1-5, "Q2": 1-5, "Q3": 1-5, "Q4": 1-5},
  "vetoes": ["命中的一票否决项，可空"],
  "risks": ["主要风险，可空"],
  "conditions": ["条件/下一轮建议，可空"],
  "short_term_only": false   // 若只衡量短期即战力，true 时"有条件录用"降级为"不录用"
}
"""
import json
import sys


def conclude(data: dict) -> dict:
    scores = data.get("scores", {})
    vetoes = data.get("vetoes", []) or []
    risks = data.get("risks", []) or []
    conditions = data.get("conditions", []) or []
    short_term = bool(data.get("short_term_only", False))

    dims = ["Q1", "Q2", "Q3", "Q4"]
    q = {k: int(scores.get(k, 0)) for k in dims}
    total = sum(q.values())
    low_dims = [k for k in dims if q[k] <= 2]

    if vetoes:
        conclusion = "不录用"
        reason = "命中一票否决：" + "；".join(vetoes)
    elif total >= 15 and not low_dims:
        conclusion = "直接录用"
        reason = f"总分 {total}/20，各维度均≥3，无否决红旗，达到通过线。"
    elif total < 15 or low_dims:
        if short_term:
            conclusion = "不录用"
            reason = (f"总分 {total}/20（通过线≥15）"
                      + (f"，维度 {','.join(low_dims)}≤2" if low_dims else "")
                      + "；按短期即战力口径，未达直接上岗标准。")
        else:
            conclusion = "有条件录用"
            bits = []
            if total < 15:
                bits.append(f"总分 {total}/20 未达通过线")
            if low_dims:
                bits.append(f"短板维度 {','.join(low_dims)}≤2（录用后最大风险）")
            reason = "；".join(bits) + "。存在可改善项，需条件/过渡期或背调复试验证。"
    else:
        conclusion = "不录用"
        reason = "未达通过线且无明确可改善路径。"

    return {
        "candidate": data.get("candidate", "候选人"),
        "scores": q,
        "total": total,
        "low_dims": low_dims,
        "vetoes": vetoes,
        "conclusion": conclusion,
        "reason": reason,
        "risks": risks,
        "conditions": conditions,
    }


def render_md(r: dict) -> str:
    """结论先行：核心结论大号加粗置顶首屏，再附关键发现/核心判断/行动建议，最后给数据支撑。"""
    lines = []
    lines.append(f"# 录用结论：{r['conclusion']}")
    lines.append(f"> **一句话理由**：{r['reason']}")
    lines.append("")
    lines.append("**关键发现**")
    for x in (r["risks"] or ["—"]):
        lines.append(f"- {x}")
    lines.append("")
    lines.append("**核心判断**")
    lines.append(f"{r['conclusion']} —— {r['reason']}")
    lines.append("")
    lines.append("**行动建议**")
    for x in (r["conditions"] or ["—"]):
        lines.append(f"- {x}")
    lines.append("")
    lines.append("---")
    lines.append("")
    lines.append("**数据支撑**")
    lines.append(f"- 维度分：Q1={r['scores']['Q1']}  Q2={r['scores']['Q2']}  Q3={r['scores']['Q3']}  Q4={r['scores']['Q4']}")
    lines.append(f"- 总分：**{r['total']}/20**（通过线 ≥15 且无单项≤2）")
    lines.append(f"- 一票否决扫描：{'无' if not r['vetoes'] else '命中：' + '；'.join(r['vetoes'])}")
    return "\n".join(lines)


# ===== 结论状态 → 颜色 映射规则（单一来源，全局唯一）=====
# conclude() 仅可能返回三态之一；颜色按状态动态判定，确保三种状态清晰可区分。
#   直接录用     → 绿色 green   #1B9E5A（白字）
#   不录用       → 红色 red     #D64545（白字）
#   有条件录用   → 黄色 amber   #E0A500（深字 #1A2B42）
COLOR_MAP = {
    "直接录用":   {"bg": "#1B9E5A", "fg": "#FFFFFF", "cls": "v-direct"},
    "不录用":     {"bg": "#D64545", "fg": "#FFFFFF", "cls": "v-no"},
    "有条件录用": {"bg": "#E0A500", "fg": "#1A2B42", "cls": "v-cond"},
}
DEFAULT_COLOR = {"bg": "#E0A500", "fg": "#1A2B42", "cls": "v-cond"}  # 兜底（理论上不触发）


def verdict_color(conclusion: str) -> dict:
    """状态判定逻辑：精确匹配三态结论 → 返回对应配色（bg/fg/cls）。"""
    return COLOR_MAP.get(conclusion, DEFAULT_COLOR)


def _verdict_class(conclusion: str) -> str:
    return verdict_color(conclusion)["cls"]


def render_html(r: dict) -> str:
    """深蓝主题 HTML 片段（结论先行）：结论卡 + 关键发现/核心判断/行动建议 + 数据支撑。
    结论状态动态着色（内联 style 保证即使脱离外部 CSS 也清晰可区分）。
    可嵌入 output_template.html 的 §0 与 §C，或由 --html 单独输出。"""
    vc = verdict_color(r["conclusion"])
    vcls = vc["cls"]
    vstyle = f"background:{vc['bg']};color:{vc['fg']};"
    findings = "".join(f"<li>{x}</li>" for x in (r["risks"] or ["—"]))
    actions = "".join(f"<li>{x}</li>" for x in (r["conditions"] or ["—"]))
    veto = "无" if not r["vetoes"] else "命中：" + "；".join(r["vetoes"])
    s = r["scores"]
    return f"""<div class="hero">
  <div class="label">录用结论 · CONCLUSION FIRST</div>
  <div class="cand">候选人：{r['candidate']}</div>
  <p class="verdict {vcls}" style="{vstyle}">{r['conclusion']}</p>
  <div class="reason">{r['reason']}</div>
  <div class="kpis">
    <div class="kpi"><h4>关键发现</h4><ul>{findings}</ul></div>
    <div class="kpi"><h4>核心判断</h4><ul><li>{r['conclusion']} —— {r['reason']}</li></ul></div>
    <div class="kpi"><h4>行动建议</h4><ul>{actions}</ul></div>
  </div>
</div>

<section>
  <h2>§C 数据支撑</h2>
  <table>
    <thead><tr><th>维度</th><th>得分(1-5)</th><th>判定</th></tr></thead>
    <tbody>
      <tr><td>动机与认知 (Q1)</td><td>{s['Q1']}</td><td>—</td></tr>
      <tr><td>能力与业绩 (Q2)</td><td>{s['Q2']}</td><td>—</td></tr>
      <tr><td>资源可迁移 (Q3)</td><td>{s['Q3']}</td><td>—</td></tr>
      <tr><td>合规与文化 (Q4)</td><td>{s['Q4']}</td><td>—</td></tr>
    </tbody>
  </table>
  <p class="meta">总分：<b>{r['total']}/20</b> ｜ 通过线：≥15 且无单项≤2 ｜ 一票否决扫描：{veto}</p>
</section>"""


def main():
    html = "--html" in sys.argv
    raw = None
    if "--json" in sys.argv:
        i = sys.argv.index("--json")
        raw = sys.argv[i + 1]
    elif not sys.stdin.isatty():
        raw = sys.stdin.read().strip()
    if not raw:
        print("用法: echo '{...}' | score_conclusion.py [--html]  或  score_conclusion.py --json '{...}'", file=sys.stderr)
        sys.exit(2)
    data = json.loads(raw)
    r = conclude(data)
    if html:
        print(render_html(r))
    else:
        print(render_md(r))
        print("\n```json")
        print(json.dumps({"conclusion": r["conclusion"], "total": r["total"],
                          "scores": r["scores"], "vetoes": r["vetoes"]}, ensure_ascii=False, indent=2))
        print("```")


if __name__ == "__main__":
    main()
